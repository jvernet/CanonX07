// This script installs shortcut in Windows Program Menu
// and registry keys so that CAS/LST CONVERTER


Shell = WScript.CreateObject("WScript.Shell");
FullName = WScript.ScriptFullName;
XuRPath = FullName.substr(0, FullName.length-WScript.ScriptName.length-15);

fso = new ActiveXObject("Scripting.FileSystemObject");

answer=Shell.Popup("This scrip will install a new folder in Windows Program Menu \n"
		+"\nLink Windows ...\n\n"
		,0,"Cas/Lst links",32);

 key =  "HKEY_CLASSES_ROOT\\"
 Shell.RegWrite( key + "Applications\\LST2CAS.EXE\\shell\\open\\command\\", "\""+XuRPath+"LST2CAS.exe\" \"%1\"");
 Shell.RegWrite( key + ".CAS\\", "LST2CAS.CAS");
 Shell.RegWrite( key + ".LST\\", "LST2CAS.LST");

 Shell.RegWrite( key + "LST2CAS.CAS\\", "X-07 VIRTUAL Tape (RAW)");
 Shell.RegWrite( key + "LST2CAS.LST\\", "X-07 VIRTUAL Tape (BIN)");

 Shell.RegWrite( key + "LST2CAS.LST\\DefaultIcon\\", XuRPath+"\WIN_automation\\lstFILES.ICO");
 Shell.RegWrite( key + "LST2CAS.CAS\\DefaultIcon\\", XuRPath+"\WIN_automation\\casFILES.ICO");

 Shell.RegWrite( key + "LST2CAS.LST\\shell\\Launch LST2CAS converter.\\command\\", "\""+XuRPath+"LST2CAS.exe\"\"%1\"");
 Shell.RegWrite( key + "LST2CAS.CAS\\shell\\Launch LST2CAS converter.\\command\\", "\""+XuRPath+"LST2CAS.exe\"\"%1\"");

// Open X07 emulator ...
 Shell.RegWrite( key + "Applications\\X07.EXE\\shell\\open\\command\\","\"C:\\Emulateurs\\X07\\x07.exe\"\"%1\"");
 Shell.RegWrite( key + "X07.CAS\\shell\\Launch X07 emulator.\\command\\", "\"C:\\Emulateurs\\X07\\x07.exe\"\"%1\"");

// Ajout d'un lecteur .cas
Shell.RegWrite( key + "basfile\\shell\\LST2CAS\\", "Convert X-07 Cas/LST file...");
Shell.RegWrite( key + "basfile\\shell\\LST2CAS\\command\\", "\""+XuRPath+"LST2CAS.exe\" \"%1\"");
// Ajout d'un lecteur .lst
Shell.RegWrite( key + "basfile\\shell\\LST2CAS\\", "Convert X-07 LST/Cas file...");
Shell.RegWrite( key + "basfile\\shell\\LST2CAS\\command\\", "\""+XuRPath+"LST2CAS.exe\" \"%1\"");

