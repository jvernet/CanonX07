Tron.

tir� du magazine Hebdogiciel N�51

	Inspir� du film de Walt Disney du m�me nom, ce jeu combine habilet� et strat�gie.
	Il se joue en 10 manches et le premier joueur dont le point heurte un obstacle, perd une manche.

Instructions :
	Le joueur 1 se d�place avec W, Q, E et Z, et le joueur 2 avec les touches fl�ch�es.

T�l�charg� sur "Hebdogiciel, les listings..." (http://www.hebdogiciel.fr)


Cordialement,
Christian DUBROEUCQ.