Basic �tendu ( 4221 pas de programme )
tir� du magazine Hebdogiciel N�156

	Augmentez efficacement et � moindre frais les performances de votre Basic.

Mode d'emploi :
	En r�gle g�n�rale, n'oubliez pas que le signe "\" correspond au signe "yen" qui s'obtient par "?" en mode GRPH.
	Videz la m�moire fichier si celle-ci est occup�e et sauvegardez le listing 1 de la mani�re suivante 
FSET 2048:SAVE "logeLM
	Tapez ensuite et lancez le listing 2 pour l'implantation du langage machine ( le listing 3 contient � titre indicatif la routine d�sassembl�e ). Un "bip" grave signale la pr�sence d'une erreur �ventuelle. Cette derni�re dans les sommes de contr�les, les lignes 30 et 40 sont list�es, sinon l'ordinateur indique la ligne erronn�e. Le langage machine en m�moire, le Canon s'�teint. A l'allumage, le message contenu dans START$ initialise les fonctions. Si vous faites DIR, vous devez obtenir :
LogeLM P BasicE D
2048/367
	L'originalit� de ce programme r�side dans le fait qu'il se reloge selon le mouvement de la m�moire fichier. Toutefois, la fonction FSET s'utilise diff�remment et c'est l� qu'intervient le fichier "LogeLM". Pour r�server N octets, il faut faire :
SLEEP:FSET n:RUN"LogeELM
	Ainsi, SLEEP supprime les nouvelles fonctions et RUN "LogeLM reloge la routine et r�initialise le START$ en �teignant la machine par OFF1. Si dans un autre cas vous perdez accidentellement le contenu de START$, RUN "LogeLM le r��initialise. Ce petit inconv�nient est largement compens� par les avantages incontestables des nouvelles fonctions que voici :
- vitesse d'affichage am�lior�e : tr�s utile, v�rifiez cette rapidit� par DIR, LIST ou PRINT "message...". Le curseur est parfois un peu perturb� lors d'un LIST @ ou d'un LINEINPUT, mais l'appui sur une touche remet tout en ordre.
- PAINT x,y : �change le contenu des variables x et y ( SWAP ), exemple : A=3:B=2:PAINT A,B nous donne B=3 et A=2.
	A$="+":B$="*":PAINT A$,B$ nous donne A$="*" et B$="+". Cel� marche �galement avec des tableaux. Attention, si ce sont des chaines, le "$" est obligatoire pour le terme de gauche, m�me s'il y a eu l'ordre DEFSTR, exemple : DEFSTR A,B:A$="+":B="*":PAINT A$,B ou bien PAINT B$,A
- COLOR "xxxx" : prot�ge le Canon avec le mot de passe "xxxx", exemple : COLOR "TOTO". Lorsque vous utilisez cette fonction, le Canon s'�teint et au rallumage, vous disposez d'environ 4 secondes pour entrer le mot de passe ( les lettres tap�es ne s'affichent pas ). Le temps �coul� et le mot incorrect, l'ordinateur retourne � son sommeil. Donc, n'oubliez pas le mot de passe sous peine de devoir user d'un RESET destructeur, car OFF et ON sont inop�rants.
- CIRCLE : GOTO, GOSUB, RESTORE et RESUME acceptent des expressions alg�briques, exemple :
	X=10:CIRCLE GOTO X
	X=10:CIRCLE GOSUB X*10
	X=10:CIRCLE RESTORE X+2+X
	X=10:CIRCLE RESUME 2*X+3+LOG(X)/LOG(10)
	�quivaut � GOTO 10, GOSUB 100, RESTORE 110, RESUME2001. Aucune modification de CIRCLE(x,y),z qui trace toujours un cercle.
- PSET ON et OFF : MERGE 2 programmes, exemple : sauvez la ligne 10 GOTO 0 en RAM par SAVE "ESSAI", puis faites NEW. Tapez la ligne 0?"*HEBDOGICIEL*" et FAITES PSET ON. Le curseur s'affiche, chargez alors par LOAD "ESSAI votre 1er programme sauvegard� et faites PSET OFF. Vos 2 programmes se trouvent "merg�s" ( v�rifiez par LIST ). Veillez toutefois � ce que les N� des lignes du programme � coller, soient strictement sup�rieurs � ceux des lignes du programme d�j� en m�moire. Aucune modification de PSET (x,y) qui allume toujours un point.
- PRESET @ ou [ valeur intiale, valeur finale,, incr�ment : affiche des valeurs enti�res et permet des boucles d'affichage ultra-rapide, exemple : PRESET @ A �crit le contenu de A ( compris entre -32767 et 32768 ) sans laisser d'espace avant et apr�s le r�sultat. PRESET @ 0,1000,2 ou PRESET @0 TO 1000 STEP 2 �crit une boucle de 0 � 1000 avec  un incr�ment de 2 ( qui est de 1 par d�faut ). PRESET [15,0,-1 ou PRESET [15TO0STEP-1 �crit une boucle de 15 � 0 avec un d�cr�ment de 1. Pour utiliser des nombres n�gatifs ( par exemple de -1 � -100 ), il faut faire : ?"-";:PRESET @1,100 ou ?"-";PRESET @1TO100. Sachez que toutes les valeurs peuvent �tre des expressions alg�briques qui ne doivent pas �tre inf�rieures � -32767 et sup�rieures � 32768. Aucune modification de PRESET (x,y) qui efface toujours un point. 
- LINE : relie plus de 2 points ensemble, exemple : LINE (0,0)-(119,0)-(0,31)-(0,0). Aucune modification de LINE INPUT.
	Vous sont offerts gracieusement 7 courts programmes de d�monstration :
BLITZ : afin d'atterrir, bombardez des immeubles par espace. Niveau de difficult� croissant.
LOTO : tirage speed� de 6 num�ros avec minimum de graphisme.
CLASS : classe des mots par ordre alphab�tique.
HHMMSS : donne l'heure avec les centi�mes de seconde.
PASS : initialise une touche de fonction pour d�clencher un mot de passe.
DECI : donne les d�cimales � l'infini d'une fraction de 2 nombres entiers.
COMPTE : vous fait jouer au jeu "le compte est bon".
