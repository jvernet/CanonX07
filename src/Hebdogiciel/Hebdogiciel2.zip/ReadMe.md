# Hebdogiciel

___
## Introduction

1983 - 1987 : Imaginez un hebdo qui, en plus de nous fournir un programme par semaine à taper,
en plus de donner des tests matériels et logiciels sans concession (et c'est pas rien de le dire),
donnait les programmes tv, les sorties cinémas, musiques et bd, des cours d'assembleur, une bd,
un club pour payer moins cher, des soluces...\
Un ton qui décoiffe de la première à la dernière page, les dessins de Carali pour remplir les trous, des procès en pagaille...\
Tout simplement hors-norme, inégalé.

Présentation du magazine réalisée par del63\
[Abandonware Magazine](https://abandonware-magazines.org/affiche_mag.php?mag=7)

___
## Codes Sources de références

[Listing](http://www.hebdogiciel.free.fr/CANONX07.htm)

[Cassette Hebdogiciel](http://www.hebdogiciel.free.fr/CANONX07_software)

Report des sources dans ce GIT, attention uniquement les sources pour le moment.\
Travail en cours.

___
## Liste

Tableau de suivi :

| Icon | État |
|------|-------|
|  ✅  | Terminé et fonctionnel |
|  ❌  | Echec |
|  ❕  | À faire |
|  📝  | En cours |

Travail en cours.

| Nom | État | Commentaire |
|-----|------|-------------|

___
