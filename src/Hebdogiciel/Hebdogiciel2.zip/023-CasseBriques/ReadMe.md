# Casse Brique (1984)(Hebdogiciel)(FR)

___
## Introduction

Qui a dit que le Canon X-07 ne cassait pas des briques ?\
Cette injustice est enfin réparée grâce au programme suivant qui vous démontre que vôtre Canon est capable de tout, comme les plus grosse machines.

___
##

___
