Blackjack.
tir� du magazine Hebdogiciel N�41

	Voici un classique des jeux de cartes. Le but? Ne pas d�passer 21...
	Ce programme est en deux parties : la premi�re servant � red�finir les caract�res, la seconde �tant le jeu lui-m�me. Pour le rentrer :
- entrez la premi�re partie
- sauvegardez-la sur cassette ( v�rifiez )
- lib�rez l'espace RAM
- entrez le programme principal
- sauvegardez-le ( v�rifiez )
- rechargez le premier programme, en laissant le magn�to en mode "PLAY". Faites RUN.
	Durant le d�roulement, r�pondre par O ou N aux questions suivantes :
doubler : prendre une seule carte et doubler la mise ( n'est possible que si le score est sup�rieur ou �gal � la mise )
partage : partager le jeu en deux jeux dont la mise de chacun est �gale � la mise pr�c�dente.
pour ASSURANCE ( miser sur le black jack du banquier ), appuyer sur espace ou RETURN.
pour se servir d'une carte : "C"
pour arr�ter le service des cartes ( servi ) :"S"

T�l�charg� sur "Hebdogiciel, les listings..." (http://www.hebdogiciel.fr)


Cordialement,
Christian DUBROEUCQ.