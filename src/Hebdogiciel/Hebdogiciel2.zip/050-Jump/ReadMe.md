Jump ( pas de programme )
tir� du magazine Hebdogiciel N�50

	Dure �preuve pour aujourd'hui...En effet, il va s'agir pour vous de grimper sur des escaliers roulants pour d�samorcer une bombe qui ne demande, bien s�r, qu'� exploser pour vous transformer en chaleur et lumi�re. Attention!!!on perd rapidement des points et de plus, il s'agit d'aller vite...
	Un jeu tr�s prenant, en trois tableaux.

Mode d'emploi :
	Apr�s avoir ex�cut� un "RUN" le programme se pr�sente. Vous pouvez aussi �viter le g�n�rique en pressant la touche "RETURN". Vous devez ensuite choisir votre niveau. Si vous optez pour le premier, vous aurez deux fois moins de temps qu'avec le niveau normal.
	Lorsque vous r�ussissez le saut, vous avez droit � un bonus qui augmente au fur et � mesure que vous r�ussissez chaque �tage.
	De plus, pour prendre en compte la rapidit� du joueur, le temps restant est ajout� au score final � la fin de chaque �tape.
	Enfin, si vous avancez vers l'extr�mit� gauche, vous vous retrouverez � droite. Je vous laisse donc d�couvrir le truc pour d�samorcer rapidement la bombe...

T�l�charg� sur "Hebdogiciel, les listings..." (http://www.hebdogiciel.fr)


Cordialement,
Christian DUBROEUCQ.