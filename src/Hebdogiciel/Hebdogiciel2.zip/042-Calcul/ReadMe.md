CALCUL

tir� du magazine Hebdogiciel N�42

	Ce programme un peu long est destin� � un X07 avec extension m�moire 8Ko mais on peut aussi le diviser et l'adapter � la version standard. Il transforme votre machine en supercalculatrice comme vous le montrera le menu que nous allons d�tailler.
	Il permet de multiplier entre eux deux nombres ayant chacun plusieurs dizaine de chiffres divis�s en groupe de 6 en d�butant par les unit�s, ou d'�lever un nombre � la puissance voulue ( pour cela indiquer � la demande la puissance, ou sinon RETURN ). Donner le nombre de groupes de chacun et les entrer en d�butant par la gauche de chaque nombre.
	Donne tous les chiffres de la factorielle d'un nombre.
	Divise deux nombres. Donner le nombre de chiffres du diviseur et les entrer par groupes de 6 comme pour le 1, puis le nombre de chiffres du dividende qu'il faut entrer � la suite sans RETURN, dire combien de chiffres sont d�sir�s au quotient;on vous indique apr�s quel chiffre devra �tre le d�cimal et la r�ponse arrive en groupe de 6 elle aussi.
	Trouve la racine carr�e d'un nombre donn� : indiquer point le d�cimal et apr�s, le nombre de d�cimales que vous voulez au quotient;diviser le nombre en tranches de 2 � partir du point d�cimal, avant comme apr�s celui-ci et entrer les tranches � la demande. Attendre que la machine vous indique la place du point d�cimal et noter les groupes de 6 chiffres. Donne les facteurs premiers d'un nombre ayant jusqu'� 14 chiffres.
Bases : 3 programmes diff�rents : sans d�cimales, avec d�cimales, avec calculs, les deux premiers font les changements de bases, le troisi�me dans une base donn�e fait successivement les op�rations qui lui sont indiqu�es avec les nombres qui lui ont �t� fournis.
	Recherche les nombres premiers, jumeaux ( 2 nombres premiers dont la diff�rence est 2 ou non ).

T�l�charg� sur "Hebdogiciel, les listings..." (http://www.hebdogiciel.fr)


Cordialement,
Christian DUBROEUCQ.