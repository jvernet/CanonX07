G�n�rateur musical.


tir� du magazine Hebdogiciel N�47

	En avant la zizique! quatre octaves, variation de la dur�e des notes et enregistrement des morceaux compos�s. Bricolez-vous un cable pour brancher des �couteurs et vous avez presque un X-07 Walkman.

Mode d'emploi :
	Ce programme fonctionne sur Canon X-07 version 8Ko. Il offre deux possibilit�s :
- jeu direct avec les touches 1 � 8 du clavier, les di�ses et b�mols �tant obtenus par la touche SHIFT.
- m�morisation d'un air dans un tableau de variables. Il vous est possible de visualiser l'air enregistr�, afin de l'int�grer dans un autre programme.
	La gamme s'�tend sur 4 octaves ( 0 � 3 ). Le changement d'octave s'effectue en appuyant sur SHIFT > ou >. Le changement de dur�e de chaque son s'effectue en appuyant sur V puis SHIFT < ou >.
	Lors de la m�morisation d'un air, une note ne sera enregistr�e que si elle est suivie d'une pression sur la touche SPACE ( espace ). Ceci permet d'�viter toute erreur de frappe d'une note. Un morceau sera restitu� avec la touche P ( play ).

T�l�charg� sur "Hebdogiciel, les listings..." (http://www.hebdogiciel.fr)


Cordialement,
Christian DUBROEUCQ.