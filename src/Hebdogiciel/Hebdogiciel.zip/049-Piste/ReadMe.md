Piste.

tir� du magazine Hebdogiciel N�49

	Vous voici transform� en pilote de course et devez faire le plus grand nombre de tour le plus rapidement possible, sans sortir de la piste.
	Bonne chance !

Instructions :
	En faisant RUN, un circuit apparait sur l'�cran. Vous vous trouvez au volant d'une voiture symbolis�e par un point. La voiture peut se manoeuvrer dans 8 directions, gr�ce aux touches de d�placement du curseur. La voiture dispose d'une vitesse rapide et d'une vitesse lente. On passe de l'une � l'autre en appuyant sur la touche fonction 6.

T�l�charg� sur "Hebdogiciel, les listings..." (http://www.hebdogiciel.fr)


Cordialement,
Christian DUBROEUCQ.