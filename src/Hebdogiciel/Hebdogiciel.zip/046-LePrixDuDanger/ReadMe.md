Le prix du danger.

tir� du magazine Hebdogiciel N�46

	Traverser une ville poursuivi par des chasseurs arm�s jusqu'aux dents, �viter les dalles �lectrifi�es tout en surveillant votre chronom�tre, ca vous tente?
	Tout d'abord, si ce n'est d�j� fait, faire CONSOLE,,,0 pour supprimer le d�clic de touche et ainsi �viter des interf�rences dans les sons produits par le haut-parleur de votre Canon. Apr�s avoir lanc� le programme et avoir pris connaissance du titre, l'ordinateur vous demande le nombre de chasseurs contre lesquels vous d�sirez lutter; au d�but un seul est largement suffisant! Ensuite, l'�cran se vide et laisse la place au plan de la ville, ce plan pourra d'ailleurs �tre modifi�, voire remplac� par les utilisateurs ( lignes 100 � 490 ). A l'extr�me droite de l'�cran apparait le mot TIME et en-dessous un chronom�tre allant de 110 � 0, une fois cette limite atteinte vous perdez une de vos trois vies. Vous �tes repr�sent� par un point lanc� dans un batiment en bas � gauche du chronom�tre.
	Le ou les chasseurs partent � votre poursuite quand le chrono atteint 90. Les chasseurs sont arm�s et vous tirent dessus uniquement dans les lignes droites, sachez cependant que plus vous �tes loin d'eux et plus vous avez de chance de leur �chapper. Les d�placements du pourchass� se font gr�ce aux fl�ches du clavier, notez cependant que les d�placements en diagonale sont possibles et conseill�s, par la pression de deux fl�ches simultan�ment. Pour vous d�barasser de vos poursuivants il vous faudra atteindre une des deux cases situ�es devant le b�timent � l'extr�me gauche de l'�cran.
	Attention, un balayeur r�calcitrant �lectrifie certaines dalles du sol, il est �vident qu'il ne faut pas se trouver dessus, sinon...Les d�placements de votre personnage qui se trouve � l'extr�me droite de l'�cran s'effectuent de la m�me mani�re que lors de la premi�re �preuve . Vous devrez faire face au balayeur ( situ� � l'extr�me gauche ) et appuyer sur la barre d'espacement. Si vous avez terrass� le balayeur, l'ordinateur vous f�licitera et vous accordera le droit de ...recommencer.

T�l�charg� sur "Hebdogiciel, les listings..." (http://www.hebdogiciel.fr)


Cordialement,
Christian DUBROEUCQ.