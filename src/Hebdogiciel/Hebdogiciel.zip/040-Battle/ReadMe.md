Battle ( 4786 pas de programme )
			tir� du magazine Hebdogiciel N�40


� retaper car il a fallu effacer la ligne 96

	Ce jeu n'est pas comme on pourrait le croire une bataille sans piti� entre 2 vaisseaux, malgr� le nom. Vous poss�dez plusieurs armes pour d�truire l'ennemi alors qu'en face le vaisseau ne poss�de qu'une seule arme : le tir.
	Mais attention, il ne faut pas trop abuser de vos moyens, cela pourrait vous �tre n�faste.

Mode d'emploi :
	Pour d�placer votre navette, actionner le bouton haut et bas du curseur. Pour tirer, actionner le bouton droit du curseur. Vous pouvez vous prot�ger avec le bouton gauche du curseur. Pour se rendre dans l'hyper espace, actionner la touche H. Cette touche permet de d�compresser 1,15 minutes. La touche "Heure/Ch" permet de tirer et d'avoir obligatoirement son adversaire.

T�l�charg� sur "Hebdogiciel, les listings..." (http://www.hebdogiciel.fr)


Cordialement,
Christian DUBROEUCQ.