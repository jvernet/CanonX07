# Carré diabolique (1983)(Hebdogiciel](FR)

Hebdogiciel, 9 décembre 1983

___
## Introduction

Plus dur qu'un simple casse-tête, plus difficile qu'un puzzle, plus fort que le rubik's cube : un coup de canon dans les jeux de patience !
Luc Lévy

___
## Mode d'emploi

Vous avez le choix entre 2 niveaux de difficulté et 3 options : l'option 5 vous permet de choisir les 9 caractères que vous désirez. Les options 1 à 3 proposent 3 puzzles basés sur une tête d'écureuil avec 3 expressions différentes. L'option 4 vous propose de reconstituer un carré.

Le nombre de coups est affiché ainsi que le temps passé depuis le début de la partie. Les touches utiles sont :
- version originale : QWE-ASD-ZXC


Si une touche d'angle est désignée, la lettre désignée et les 2 lettres contiguës tournent dans le sens des aiguilles d'une montre. Par contre, si une touche de milieu est désignée, les 2 angles et le centre tournent dans le sens des aiguilles d'une montre.

Au niveau 2, le sens est inversé pour les lettres d'angles; idem pour les lettres de milieu, mais en plus le milieu désigné s'inverse avec son opposé. Diablement diabolique, non ?

___