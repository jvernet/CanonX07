ANNEXE 1
LISTE DES CODES

|  CODE | MNEMONIQUE | INDICATEURS  |
| --- | --- | --- |
|  8E | ADC A.(HL) |   |
|  DD8Edpl | ADC A.(IX + dpl) |   |
|  FD8Edpl | ADC A.(IY + dpl) |   |
|  8F | ADC A.A |   |
|  88 | ADC A.B |   |
|  89 | ADC A.C |   |
|  8A | ADC A.D |   |
|  8B | ADC A.E |   |
|  8C | ADC A.H |   |
|  8D | ADC A.L |   |
|  CEv | ADC A.v |   |
|  ED4A | ADC HL,BC |   |
|  ED5A | ADC HL,DE |   |
|  ED6A | ADC HL,HL |   |
|  ED7A | ADC HL,SP |   |
|  86 | ADD A.(HL) |   |
|  DD86dpl | ADD A.(IX + dpl) |   |
|  FD86dpl | ADD A.(IY + dpl) |   |
|  87 | ADD A.A | modifiés  |
|  80 | ADD A.B |   |
|  81 | ADD A.C |   |
|  82 | ADD A.D |   |
|  83 | ADD A.E |   |
|  84 | ADD A.H |   |
|  85 | ADD A.L |   |
|  C6v | ADD A.v |   |
|  09 | ADD HL,BC |   |
|  19 | ADD HL,DE |   |
|  29 | ADD HL,HL |   |
|  39 | ADD HL,SP |   |
|  DD09 | ADD IX,BC |   |
|  DD19 | ADD IX,DE |   |
|  DD29 | ADD IX,IX |   |
|  DD39 | ADD IX,SP |   |
|  FD09 | ADD IY,BC |   |
|  FD19 | ADD IY,DE |   |
|  FD29 | ADD IY,IY |   |
|  FD39 | ADD IY,SP |   |

137