Il se redresse, me fixe de son regard profond et joint ses deux mains. J'éprouve une sensation de béatitude mêlée d'un sentiment de profonde sécurité. J'ai compris qu'il va accéder à ma requête ... Il va me transmettre son savoir !

ASSEMBLUS se dirige lentement vers le fond de la pièce et fait pivoter un panneau sculpté. Il me fait signe de le suivre et je découvre une salle au centre de laquelle se trouve un CANON X-07 ! Le micro a l'air en parfait état de fonctionnement et se trouve relié à plusieurs périphériques tels que des imprimantes, des écrans, des coupleurs optiques ...

Le sage effleure la touche ON/OFF du X-07 et toute la pièce se met à tracer, à dessiner, à vibrer, à se colorer, à chanter ... Il comprend mon étonnement et déclare :

"Tu as l'air très étonné CANDORE mais cela est tout à fait normal ... Le CANON X-07 reste la seule machine dans la galaxie à pouvoir être commandée en ASSEMBLEUR Z-80. La guilde informatique ayant imposé son langage et ses normes, l'ASSEMBLEUR a été proprement éliminé et plus personne ne peut visiter les entrailles de sa machine, comme jadis ... J'appartiens à un autre temps, à une autre époque. Je sais que ma mort est proche mais je ne veux pas commencer mon dernier voyage sans avoir légué la pratique du langage ASSEMBLEUR à quelqu'un de noble. Si tu le désires, je peux t'apprendre ce langage pour que tu puisses, toi CANDORE, dompter, maîtriser et ne plus être l'esclave de ta machine. Le CANON sera alors pour toi la machine idéale et tu pourras réaliser tout ce qu'il fait en ce moment ..."

J'acquiesce lentement et ASSEMBLUS me conduit sous un casque à positrons rapides permettant à n'importe quel être humain d'emmagasiner des milliers d'informations très rapidement. Je perçois le démarrage du disque optique et je m'endors, bercé par le doux ronronnement des données pénétrant mon cerveau ...

# OCTOBRE 1985, QUELQUE PART EN FRANCE, 4 h 15 ...

Je sursaute et je m'aperçois que je suis en sueur ... Drole de rêve !! Décidément, l'ASSEMBLEUR me travaille ! Je glisse un œil vers mon radio-réveil : 4 h 17. Je me lève et m'assieds à mon bureau ... Un CANON X-07, une dizaine de feuilles de listing, une imprimante et trois crayons occupent toute la table.

Ah, si mon rêve se réalisait un jour ... Etre détenteur du langage ASSEMBLEUR, comprendre les moindres particularités du X-07 et avoir visité ses recoins les plus secrets ! Cela fait plus de 15 jours que je n'ai pas avancé ...

Mais un détail attire mon attention ... J'ai complètement oublié d'ouvrir le paquet cadeau offert par Odile pour mon anniversaire !!

D'une main fébrile, je le décachète délicatement et, ô miracle, je découvre l'ouvrage traitant du "CANON X-07 et de l'ASSEMBLEUR".

Best Seller depuis des mois, il est épuisé dans toutes les librairies car tous les utilisateurs du X-07 se l'arrachent ! En effet, depuis la parution de cet ouvrage, des milliers de possesseurs de CANON ont appris à mieux connaître leur micro en l'exploitant de façon optimale grâce à l'ASSEMBLEUR. J'ouvre doucement ce magnifique livre et, en page de garde, une dédicace m'est adressée : "A Candore, le palais de la programmation supérieure vous est désormais accessible. Les AUTEURS".

Mes angoisses sont désormais terminées et même sans "casque à positrons", je suis certain de maîtriser bientôt parfaitement mon CANON X-07 !

A. TONIC