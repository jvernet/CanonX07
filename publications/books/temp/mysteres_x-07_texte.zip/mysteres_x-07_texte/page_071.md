138
139

|  A6 | AND (HL) |   |
| --- | --- | --- |
|  DDA6dp1 | AND (IX + dp1) |   |
|  FDA6dp1 | AND (IY+ dp1) | C=N+0  |
|  A7 | AND A | P=parité  |
|  A0 | AND B | H=1  |
|  A1 | AND C | S et 2 modifiés  |
|  A2 | AND D |   |
|  A3 | AND E |   |
|  A4 | AND H |   |
|  A5 | AND L |   |
|  E6v | AND v |   |
|  CB46 | BIT 0,(HL) |   |
|  DDCBdp146 | BIT 0,(IX + dp1) |   |
|  FDCBdp146 | BIT 0,(IY + dp1) |   |
|  CB47 | BIT 0,A |   |
|  CB40 | BIT 0,B |   |
|  CB41 | BIT 0,C |   |
|  CB42 | BIT 0,D |   |
|  CB43 | BIT 0,E |   |
|  CB44 | BIT 0,H |   |
|  CB45 | BIT 0,L |   |
|  CB4E | BIT 1,(HL) |   |
|  DDCBdp14E | BIT 1,(IX + dp1) |   |
|  FDCBdp14E | BIT 1,(IY + dp1) |   |
|  CB4F | BIT 1,A |   |
|  CB48 | BIT 1,B |   |
|  CB49 | BIT 1,C | Z modifié  |
|  CB4A | BIT 1,D | N=0, H=1  |
|  CB4B | BIT 1,E | C inchangé  |
|  CB4C | BIT 1,H |   |
|  CB4D | BIT 1,L |   |
|  CB56 | BIT 2,(HL) |   |
|  DDCBdp156 | BIT 2,(IX + dp1) |   |
|  FDCBdp156 | BIT 2,(IY + dp1) |   |
|  CB57 | BIT 2,A |   |
|  CB50 | BIT 2,B |   |
|  CB51 | BIT 2,C |   |
|  CB52 | BIT 2,D |   |
|  CB53 | BIT 2,E |   |
|  CB54 | BIT 2,H |   |
|  CB55 | BIT 2,L |   |
|  CB5E | BIT 3,(HL) |   |
|  DDCBdp15E | BIT 3,(IX + dp1) |   |
|  FDCBdp15E | BIT 3,(IY + dp1) |   |
|  CB5F | BIT 3,A |   |
|  CB58 | BIT 3,B  |
| --- | --- |
|  CB59 | BIT 3,C  |
|  CB5A | BIT 3,D  |
|  CB5B | BIT 3,E  |
|  CB5C | BIT 3,H  |
|  CB5D | BIT 3,L  |
|  CB66 | BIT 4,(HL)  |
|  DDCBdp166 | BIT 4,(IX + dp1)  |
|  FDCBdp166 | BIT 4,(IY + dp1)  |
|  CB67 | BIT 4,A  |
|  CB60 | BIT 4,B  |
|  CB61 | BIT 4,C  |
|  CB62 | BIT 4,D  |
|  CB63 | BIT 4,E  |
|  CB64 | BIT 4,H  |
|  CB65 | BIT 4,L  |
|  CB6E | BIT 5,(HL)  |
|  DDCBdp16E | BIT 5,(IX + dp1)  |
|  FDCBdp16E | BIT 5,(IY + dp1)  |
|  CB6F | BIT 5,A  |
|  CB68 | BIT 5,B  |
|  CB69 | BIT 5,C  |
|  CB6A | BIT 5,D  |
|  CB6B | BIT 5,E  |
|  CB6C | BIT 5,H  |
|  CB6D | BIT 5,L  |
|  CB76 | BIT 6,(HL)  |
|  DDCBdp176 | BIT 6,(IX + dp1)  |
|  FDCBdp176 | BIT 6,(IY + dp1)  |
|  CB77 | BIT 6,A  |
|  CB70 | BIT 6,B  |
|  CB71 | BIT 6,C  |
|  CB72 | BIT 6,D  |
|  CB73 | BIT 6,E  |
|  CB74 | BIT 6,H  |
|  CB75 | BIT 6,L  |
|  CB7E | BIT 7,(HL)  |
|  DDCBdp17E | BIT 7,(IX + dp1)  |
|  FDCBdp17E | BIT 7,(IY + dp1)  |
|  CB7F | BIT 7,A  |
|  CB78 | BIT 7,B  |
|  CB79 | BIT 7,C  |
|  CB7A | BIT 7,D  |
|  CB7B | BIT 7,E  |
|  CB7C | BIT 7,H  |
|  CB7D | BIT 7,L  |