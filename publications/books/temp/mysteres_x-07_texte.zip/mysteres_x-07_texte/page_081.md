Néanmoins, vous pouvez passer nous voir le mardi après-midi uniquement à l'adresse du CLUB.

Nous fournissons aux adhérents, aussi bien par courrier que de vive voix, tous les renseignements dont nous disposons sur le CANON X-07 : ROM désassemblée, cours d'apprentissage au BASIC et L.M., informations complètes sur le HARDWARE, adresses, etc...

Cette aide est appuyée par les connaissances étendues de techniciens chevronnés travaillant sur le X-07 depuis sa sortie en France : rien ne leur échappe !!

## Le CLUB C7 : une PROGRAMMATHéQUE...

Le développement de la programmathèque est lié à la participation que lui apporte nos membres : en effet, ce sont eux qui fournissent la majorité des programmes dont la liste est présente dans chaque gazette.

Pour encourager les programmeurs et garantir une bonne qualité des programmes, ceux-ci sont vendus à un prix modique (entre 5 et 20 Francs) et le programmeur reçoit chaque année la moitié du montant total de la vente de ses programmes.

Les programmes commandés sont envoyés aux adhérents sur K7 avec une notice détaillée.

## Le CLUB C7 : une COOPERATIVE...

La coopérative a pour but principal de vendre des produits moins chers que sur le marché : nous disposons de beaucoup de produits et nous souhaitons un développement massif de cette section pour offrir aux adhérents le maximum d'avantages.

Le PRESIDENT du CLUB C7

André TONIC

## BULLETIN d'INSCRIPTION au CLUB C7
## 33 AV. PHILIPPE AUGUSTE . 75011 PARIS

Je désire m'inscrire au CLUB C7 pour un an à partir de ma date d'adhésion. Je joins un chèque de 380 Francs à l'ordre du CLUB C7 (ou de 430 Francs pour l'étranger en raison des frais postaux).

NOM : ... PRENOM : ...

PROFESSION : ... AGE : ...

ADRESSE : ...

158

## PUBLICATIONS C7

|  1 | * LM & nombres aléatoires
* L'interface PERITEL X-720
* Kit appel, Maths Astro de LSC
* Jeux Magic Circus, Dactylo
* Trucs, astuces, informations
* BEEPS TRES SPECIAUX !!! | 4 | * Solitaire/Pentominos LM
* Agenda (LSC), Calc (P.S)
* Camemberts Statistiques
* Tri de nombres en LM
* Anti-BREAK en LM
* Adresses Mots-Clés  |
| --- | --- | --- | --- |
|  2 | SPECIAL LM
* Auto-programmation, adresses
* PAINT 3 fonctions graphiques
* FICHIER, ASS/DESASS de LSC
* Carte 40 Ko d'INFOSYSTEMES
* Jeu de la VIE en LM | 5 | * Traitement de textes (LM)
* adresses fin des mots-clés
* Progs en LM et BASIC
* Graphe (P.S), Forth (LSC)
* Références croisées (LM)
* Instruction BOX en LM  |
|  3 | * Le sous-processeur T6634
* Les BOOLEENS du X-07
* Les sympathisants du X-07
* Nautilus, Calc, Graphe de LSC
* Les adresses RST en folie
* COPYRIGHT en folie | 6 | * Jeux (P.S. et LSC)
* Microbox d'ADIRIS
* Les routines de conversion
* Labyrinthe 3D, alarme
* 40 programmes (ETSF)
* Des surprises  |

**Rapport de stage !**

* GENERALITES
* Mnémoniques
* Assembleur
* Modes d'adressage
* Exercices divers
* Tableau général

CLUB C7

NOM : ...

PRENOM : ...

ADRESSE : ...

☐ Je désire recevoir les Numéros ...
de la gazette au prix unitaire de 40 F.

☐ Je désire recevoir les Numéros ...
des rapports de stage au prix unitaire de 100 F.

☐ Je désire recevoir les Numéros ...
de la K7 accompagnant la gazette (pas de K7 n°3) au prix unitaire de 40 F.

TOTAL : 15 Francs de frais d'envoi : ... Francs.

0 CHEQUE 0 MANDAT 0 CCP à l'ordre du CLUB C7