# ANNEXE 4
## BIBLIOGRAPHIE

Cette bibliographie, non exhaustive, peut vous permettre de vous documenter sur tel ou tel aspect de l'ASSEMBLEUR Z-80 ou du CANON X-07.

|  EDITIONS | TITRE  |
| --- | --- |
|  SYBEX | "La programmation du Z-80" de R. ZACKS  |
|  EYROLLES | "L'ASSEMBLEUR FACILE du Z-80"  |
|  P.S.I. | "Programmer en ASSEMBLEUR" de A. PINAUD  |
|  CANON | Manuel de la carte MONITEUR XP-140F  |
|  CLUB C7 | Toutes les gazettes "Le SON du CANON"  |
|  TESTS | L'Ordinateur Individuel  |
|  S.P.E. | Micro Systèmes  |

Cet ouvrage a été composé sur :

![img-0.jpeg](img-0.jpeg)

**Réalisation PROMOCOM**

49, rue Fondary
75015 PARIS
Tél. 45 79 80 12