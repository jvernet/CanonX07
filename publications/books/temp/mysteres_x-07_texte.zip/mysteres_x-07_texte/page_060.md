Enfin !! Le mur impénétrable protégeant les entrailles du CANON X-07 a été percé ... Désormais, cette ouverture va vous permettre de progresser dans la programmation de votre machine préférée.

Il est vrai que les mystères du X-07 sont innombrables et que nous ne pourront jamais dévoiler toutes ses possibilités. Néanmoins, ces deux premières parties doivent servir de tremplin d'envol à votre essor vers le langage machine ...

Ne vous inquiétez pas, nous n'allons pas vous quitter si tôt : un lot d'applications va vous permettre de visualiser tous les concepts abordés.

![img-0.jpeg](img-0.jpeg)

VOLS SPATIAUX VERS LE SECTEUR "APPLICATIONS"

DEPECHEZ-VOUS !!!