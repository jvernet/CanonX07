152
153

|  DDCBdpiDE | SET 3,(IX + dpi)  |
| --- | --- |
|  FDCBdpiDE | SET 3,(IY + dpi)  |
|  CBDF | SET 3,A  |
|  CBD8 | SET 3,B  |
|  CBD9 | SET 3,C  |
|  CBDA | SET 3,D  |
|  CBDB | SET 3,E  |
|  CBDC | SET 3,H  |
|  CBDD | SET 3,L  |
|  CBE6 | SET 4,(HL)  |
|  DDCBdpiE6 | SET 4,(IX + dpi)  |
|  FDCBdpiE6 | SET 4,(IY + dpi)  |
|  CBE7 | SET 4,A  |
|  CBE0 | SET 4,B  |
|  CBE1 | SET 4,C  |
|  CBE2 | SET 4,D  |
|  CBE3 | SET 4,E  |
|  CBE4 | SET 4,H  |
|  CBE5 | SET 4,L  |
|  CBEE | SET 5,(HL)  |
|  DDCBdpiEE | SET 5,(IX + dpi)  |
|  FDCBdpiEE | SET 5,(IY + dpi)  |
|  CBEF | SET 5,A  |
|  CBF8 | SET 5,B  |
|  CBE9 | SET 5,C  |
|  CBEA | SET 5,D  |
|  CBEB | SET 5,E  |
|  CBEC | SET 5,H  |
|  CBED | SET 5,L  |
|  CBF6 | SET 6,(HL)  |
|  DDCBdpiF6 | SET 6,(IX + dpi)  |
|  FDCBdpiF6 | SET 6,(IY + dpi)  |
|  CBF7 | SET 6,A  |
|  CBF0 | SET 6,B  |
|  CBF1 | SET 6,C  |
|  CBF2 | SET 6,D  |
|  CBF3 | SET 6,E  |
|  CBF4 | SET 6,H  |
|  CBF5 | SET 6,L  |
|  CBFE | SET 7,(HL)  |
|  DDCBdpiFE | SET 7,(IX + dpi)  |
|  FDCBdpiFE | SET 7,(IY + dpi)  |
|  CBFF | SET 7,A  |
|  CBF8 | SET 7,B  |
|  CBF9 | SET 7,C  |
|  CBFA | SET 7,D  |

inchangés

|  CBFB | SET 7,E  |
| --- | --- |
|  CBFC | SET 7,H  |
|  CBFD | SET 7,L  |
|  CB26 | SLA (HL)  |
| --- | --- |
|  DDCBdpi26 | SLA (IX + dpi)  |
|  FDCBdpi26 | SLA (IY + dpi)  |
|  CB27 | SLA A  |
|  CB20 | SLA B  |
|  CB21 | SLA C  |
|  CB22 | SLA D  |
|  CB23 | SLA E  |
|  CB24 | SLA H  |
|  CB25 | SLA L  |
|  CB2E | SRA (HL)  |
|  DDCBdpi2E | SRA (IX + dpi)  |
|  FDCBdpi2E | SRA (IY + dpi)  |
|  CB2F | SRA A  |
| --- | --- |
|  CB28 | SRA B  |
|  CB29 | SRA C  |
|  CB2A | SRA D  |
|  CB2B | SRA E  |
|  CB2C | SRA H  |
|  CB2D | SRA L  |
|  CB3E | SRL (HL)  |
|  DDCBdpi3E | SRL (IX + dpi)  |
|  FDCBdpi3E | SRL (IY + dpi)  |
|  CB3F | SRL A  |
|  CB38 | SRL B  |
|  CB39 | SRL C  |
|  CB3A | SRL D  |
|  CB3B | SRL E  |
|  CB3C | SRL H  |
|  CB3D | SRL L  |
|  96 | SUB (HL)  |
| --- | --- |
|  DD96dpi | SUB (IX + dpi)  |
|  FD96dpi | SUB (IY + dpi)  |
|  97 | SUB A  |
|  90 | SUB B  |
|  91 | SUB C  |
|  92 | SUB D  |
|  93 | SUB E  |
|  94 | SUB H  |

inchangés