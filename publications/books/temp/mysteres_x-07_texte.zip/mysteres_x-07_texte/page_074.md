144
145

DD22nn LD (nn),IX
FD22nn LD (nn),IY
ED73nn LD (nn),SP
0A LD A,(BC)
1A LD A,(DE)
7E LD A,(HL)
DD7Edpl LD A,(IX + dpl)
FD7Edpl LD A,(IY + dpl)
3Ann LD A,(nn)
7F LD A,A
78 LD A,B
79 LD A,C
7A LD A,D
7B LD A,E
7C LD A,H
ED57 LD A,I
7D LD A,L
3Ev LD A,v
ED5F LD A,R
46 LD B,(HL)
DD46dpl LD B,(IX + dpl)
FD46dpl LD B,(IY + dpl)
47 LD B,A
40 LD B,B
41 LD B,C
42 LD B,D
43 LD B,E
44 LD B,H
45 LD B,L
06v LD B,v
ED4Bnn LD BC,(nn)
01vv LD BC,vv
4E LD C,(HL)
DD4Edpl LD C,(IX + dpl)
FD4Edpl LD C,(IY + dpl)
4F LD C,A
48 LD C,B
49 LD C,C
4A LD C,D
4B LD C,E
4C LD C,H
4D LD C,L
0Ev LD C,v
56 LD D,(HL)
DD56dpl LD D,(IX + dpl)
FD56dpl LD D,(IY + dpl)

non-affectés

57 LD D,A
50 LD D,B
51 LD D,C
52 LD D,D
53 LD D,E
54 LD D,H
55 LD D,L
16v LD D,v
ED5Bnn LD DE,(nn)
11vv LD DE,vv
5E LD E,(HL)
DD5Edpl LD E,(IX + dpl)
FD5Edpl LD E,(IY + dpl)
5F LD E,A
58 LD E,B
59 LD E,C
5A LD E,D
5B LD E,E
5C LD E,H
5D LD E,L
1Ev LD E,v
66 LD H,(HL)
DD66dpl LD H,(IX + dpl)
FD66dpl LD H,(IY + dpl)
67 LD H,A
60 LD H,B
61 LD H,C
62 LD H,D
63 LD H,E
64 LD H,H
65 LD H,L
26v LD H,v
2Ann LD HL,(nn)
21vv LD HL,vv
ED47 LD I,A
DD2Ann LD IX,(nn)
DD21vv LD IX,vv
FD2Ann LD IY,(nn)
FD21vv LD IY,vv
6E LD L,(HL)
DD6Edpl LD L,(IX + dpl)
FD6Edpl LD L,(IY + dpl)
6F LD L,A
68 LD L,B
69 LD L,C
6A LD L,D