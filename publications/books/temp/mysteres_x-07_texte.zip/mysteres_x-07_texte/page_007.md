Enfin, quelques annexes vous renseigneront efficacement sur les derniers points utiles pour continuer votre nouvelle quête de la terre promise nommée "CANONLAND".

Nous espérons que cet ouvrage sur le langage machine du CANON X-07 comblera tous les fanatiques et adorateurs de cette machine si prisée. Les portes du paradis leur sont désormais ouvertes ...

A. TONIC

SONNLAIRE

Les auteurs Page 2
Remerciements Page 3
Avant-propos Page 4
Préface Page 5
Introduction Page 9

## 1ère PARTIE : L' ASSEMBLEUR Z-80

### Chapitre 1 : GENERALITES
Page 15
1.1 Définition d'un ordinateur Page 15
1.2 Format des ordres et des données Page 15
1.3 Le binaire Page 17
1.4 La mémoire Page 19
1.5 L'hexadécimal Page 19
1.6 Le microprocesseur Page 20
1.7 Architecture du NSC 800 Page 21
1.8 Pourquoi utiliser l'ASSEMBLEUR ? Page 26

### Chapitre 2 : MNEMONIQUE &amp; ASSEMBLEUR
Page 28
2.1 Introduction Page 28
2.2 De l'utilité d'un ASSEMBLEUR Page 28
2.3 Les labels Page 29
2.4 Fonctionnalités de l'ASSEMBLEUR Page 29
2.5 Format du code source Page 30
2.6 Les arguments de l'opérande Page 32
2.7 Définition des données Page 34

### Chapitre 3 : LES MODES D' ADRESSAGE DU NSC 800
Page 36
3.1 L'adressage immédiat Page 36
3.2 L'adressage registre Page 36
3.3 L'adressage indirect registre Page 36
3.4 L'adressage direct Page 36
3.5 L'adressage relatif Page 37
3.6 L'adressage indexé Page 37
3.7 L'adressage bit Page 37