LES AUTEURS
REMERCIEMENTS

André TONIC, 19 ans, étudiant en Sciences Economiques, participe activement depuis plusieurs années à l'élaboration de nombreux logiciels commerciaux sur micro-ordinateurs aussi bien portables qu'individuels. En outre, il est co-auteur de plusieurs recueils de programmation. Il est également président du CLUB C7.

Edward AREVIAN, 23 ans, étudiant en électronique et en informatique, est conseiller technique au sein du CLUB C7. Il s'intéresse tout particulièrement à l'architecture interne des micro-ordinateurs.

Philippe MILLEY, 23 ans, a brillamment terminé ses études commerciales : il s'occupe de la trésorerie à l'intérieur du CLUB C7. De plus, il a acquis une certaine expérience dans l'exploitation des langages évolués.

Nous désirons adresser nos plus vifs remerciements à :

- Mrs De la Rue du Can et De Carville, responsables MARKETING de la société CANON FRANCE, pour leurs informations relatives au X-07.

- Melle HELAS, étudiante, pour sa participation à la composition de cet ouvrage.

- Mr ROUSSEAU, maître assistant en sciences, pour les nombreux renseignements concernant le langage machine du X-07 qu'il nous a aimablement donnés.

Les AUTEURS